To change your skin please follow the link:
https://dhtmlx.com/docs/products/skinBuilder/index.shtml#12c1a9c1fa